
<?php $__env->startSection('title','Sewa Barang'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto p-6">

    
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-slate-800">
            Sewa Barang
        </h1>

        <p class="text-slate-500 mt-1">
            Pilih perlengkapan bela diri yang ingin disewa
        </p>
    </div>


    <div class="grid grid-cols-12 gap-6">

        
        <div class="col-span-12 lg:col-span-8">

            
            <div class="bg-white rounded-2xl shadow-sm p-4 mb-6">

                <div class="relative">
                    <input type="text"
                        id="searchBarang"
                        placeholder="Cari barang..."
                        class="w-full rounded-xl pl-11 pr-4 border py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none">

                    <svg xmlns="http://www.w3.org/2000/svg"
                        class="w-5 h-5 absolute left-4 top-3.5 text-slate-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor">

                        <path stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M21 21l-4.35-4.35m1.85-5.15a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                </div>

            </div>


            
            <div id="barangContainer"
                class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">

                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="barang-item bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-lg transition duration-300">

                    
                    <div class="relative">

                        <img src="<?php echo e($b->foto ? asset('storage/'.$b->foto) : asset('img/default.png')); ?>"
                            class="h-52 w-full object-cover">

                        
                        <div class="absolute top-3 right-3">

                            <?php if($b->stok > 0): ?>
                                <span class="bg-green-500 text-white text-xs px-3 py-1 rounded-full shadow">
                                    Stok <?php echo e($b->stok); ?>

                                </span>
                            <?php else: ?>
                                <span class="bg-red-500 text-white text-xs px-3 py-1 rounded-full shadow">
                                    Habis
                                </span>
                            <?php endif; ?>

                        </div>

                    </div>


                    
                    <div class="p-4">

                        <h3 class="font-semibold text-slate-800 text-lg">
                            <?php echo e($b->nama_barang); ?>

                        </h3>

                        <div class="mt-2 flex items-center justify-between">

                            <div>
                                <p class="text-xs text-slate-400">
                                    Harga Sewa
                                </p>

                                <p class="text-blue-600 font-bold text-lg">
                                    Rp <?php echo e(number_format($b->harga_per_hari,0,',','.')); ?>

                                </p>

                                <p class="text-xs text-slate-400">
                                    / hari
                                </p>
                            </div>

                        </div>

                        
                        <div class="mt-4">

                            <?php if($b->stok == 0): ?>

                            <button
                                disabled
                                class="w-full bg-slate-300 text-white py-2.5 rounded-xl text-sm cursor-not-allowed">
                                Stok Habis
                            </button>

                            <?php else: ?>

                            <button
                                onclick="addToCart(<?php echo e($b->id); ?>, '<?php echo e($b->nama_barang); ?>', <?php echo e($b->harga_per_hari); ?>)"
                                class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl text-sm font-medium transition">

                                + Tambah ke Keranjang

                            </button>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>



        
        <div class="col-span-12 lg:col-span-4">

            <div class="bg-white rounded-2xl shadow-sm sticky top-5 overflow-hidden">

                
                <div class="p-5  bg-slate-50">

                    <h2 class="text-xl font-bold text-slate-800">
                        Keranjang Sewa
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Detail penyewaan barang
                    </p>

                </div>


                <form action="<?php echo e(route('anggota.sewa.store')); ?>"
                    method="POST"
                    class="p-5">

                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="user_id" value="<?php echo e(auth()->id()); ?>">
                    <input type="hidden" name="durasi" id="durasiHidden">


                    
                    <div class="space-y-4">

                        
                        <div>

                            <label class="block text-sm font-medium text-slate-600 mb-1">
                                Tanggal Pinjam
                            </label>

                            <input type="date"
                                name="tanggal_pinjam"
                                id="tglPinjam"
                                value="<?php echo e(date('Y-m-d')); ?>" 
                                class="w-full border rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none">

                        </div>


                        
                        <div>

                            <label class="block text-sm font-medium text-slate-600 mb-1">
                                Durasi Sewa
                            </label>

                            <select id="durasi"
                                class="w-full border rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none">

                                <?php for($i=1;$i<=9;$i++): ?>
                                <option value="<?php echo e($i); ?>">
                                    <?php echo e($i); ?> Hari
                                </option>
                                <?php endfor; ?>

                            </select>

                        </div>


                        
                        <div>

                            <label class="block text-sm font-medium text-slate-600 mb-1">
                                Tanggal Kembali
                            </label>

                            <input type="date"
                                name="tanggal_kembali_rencana"
                                id="tglKembali"
                                class="w-full border bg-slate-100 rounded-xl px-4 py-3 text-sm">

                        </div>

                    </div>


                    
                    <div class="mt-6">

                        <div class="flex items-center justify-between mb-3">

                            <h3 class="font-semibold text-slate-700">
                                Daftar Barang
                            </h3>

                            <span id="jumlahItem"
                                class="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded-full">
                                0 Item
                            </span>

                        </div>

                        <div id="cartList"
                            class="space-y-3 max-h-80 overflow-y-auto pr-1">
                        </div>

                    </div>


                    
                    <div class="mt-6 border-t pt-4">

                        <div class="flex justify-between items-center">

                            <span class="text-slate-600">
                                Total Pembayaran
                            </span>

                            <span class="text-2xl font-bold text-blue-600">
                                Rp <span id="totalHarga">0</span>
                            </span>

                        </div>

                    </div>


                    
                    <button type="submit"
                        class="w-full mt-6 bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl font-semibold transition">

                        Checkout Sekarang

                    </button>

                </form>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>




<script>

let cart = [];
let total = 0;
let lamaSewa = 1;


// SEARCH
document.getElementById('searchBarang').addEventListener('keyup', function(){

    let keyword = this.value.toLowerCase();

    document.querySelectorAll('.barang-item').forEach(item => {

        let nama = item.innerText.toLowerCase();

        if(nama.includes(keyword)){
            item.style.display = 'block';
        }else{
            item.style.display = 'none';
        }

    });

});


// ADD CART
function addToCart(id,nama,harga){

    let item = cart.find(i => i.id === id);

    if(item){
        item.qty++;
    }else{
        cart.push({
            id,
            nama,
            harga,
            qty:1
        });
    }

    renderCart();
}


// RENDER CART
function renderCart(){

    let html = '';
    total = 0;

    lamaSewa = parseInt(document.getElementById('durasi').value);

    cart.forEach((item,i)=>{

        let sub = item.harga * item.qty * lamaSewa;

        total += sub;

        html += `
        <div class="border rounded-xl p-3">

            <div class="flex justify-between items-start">

                <div>

                    <p class="font-medium text-slate-700 text-sm">
                        ${item.nama}
                    </p>

                    <p class="text-xs text-slate-400 mt-1">
                        Rp ${item.harga.toLocaleString()} / hari
                    </p>

                    <input type="hidden" name="barang_id[]" value="${item.id}">
                    <input type="hidden" name="qty[]" value="${item.qty}">

                </div>

                <button type="button"
                    onclick="hapusItem(${i})"
                    class="text-red-500 text-xs">
                    Hapus
                </button>

            </div>


            <div class="flex items-center justify-between mt-3">

                <div class="flex items-center gap-2">

                    <button type="button"
                        onclick="kurangItem(${i})"
                        class="w-7 h-7 bg-red-500 text-white rounded-lg">
                        -
                    </button>

                    <span class="font-semibold w-6 text-center">
                        ${item.qty}
                    </span>

                    <button type="button"
                        onclick="cart[${i}].qty++; renderCart()"
                        class="w-7 h-7 bg-green-500 text-white rounded-lg">
                        +
                    </button>

                </div>

                <div class="font-bold text-blue-600 text-sm">
                    Rp ${sub.toLocaleString()}
                </div>

            </div>

        </div>
        `;
    });

    document.getElementById('cartList').innerHTML = html;
    document.getElementById('totalHarga').innerText = total.toLocaleString();
    document.getElementById('jumlahItem').innerText = cart.length + ' Item';
}


// KURANG ITEM
function kurangItem(i){

    cart[i].qty--;

    if(cart[i].qty <= 0){
        cart.splice(i,1);
    }

    renderCart();
}


// HAPUS ITEM
function hapusItem(i){

    cart.splice(i,1);

    renderCart();
}


// DURASI
document.getElementById('durasi').addEventListener('change',()=>{

    lamaSewa = parseInt(document.getElementById('durasi').value);

    document.getElementById('durasiHidden').value = lamaSewa;

    updateTanggalKembali();

    renderCart();

});


// TGL PINJAM
document.getElementById('tglPinjam')
.addEventListener('change', updateTanggalKembali);


// HITUNG TGL KEMBALI
function updateTanggalKembali(){

    let tgl = document.getElementById('tglPinjam').value;

    if(!tgl) return;

    let pinjam = new Date(tgl);

    pinjam.setDate(pinjam.getDate() + lamaSewa);

    let yyyy = pinjam.getFullYear();
    let mm = String(pinjam.getMonth()+1).padStart(2,'0');
    let dd = String(pinjam.getDate()).padStart(2,'0');

    document.getElementById('tglKembali').value =
        `${yyyy}-${mm}-${dd}`;
}


// INIT
window.onload = function(){

    lamaSewa = parseInt(document.getElementById('durasi').value);

    document.getElementById('durasiHidden').value = lamaSewa;

}

</script>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/anggota/sewa.blade.php ENDPATH**/ ?>
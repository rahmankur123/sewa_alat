
<?php $__env->startSection('title','Data Barang Hilang'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-6xl mx-auto">

    
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-xl md:text-2xl font-semibold text-gray-800">
                Data Barang Hilang
            </h2>
            <p class="text-sm text-gray-500">
                Daftar barang yang hilang dalam transaksi
            </p>
        </div>
    </div>

    
    <div class="bg-white rounded-2xl shadow-sm overflow-hidden">

        <div class="overflow-x-auto">
            <table class="w-full text-sm">

                <thead class="bg-gray-100 text-gray-600 text-xs uppercase">
                    <tr>
                        <th class="px-6 py-3 text-left">No</th>
                        <th class="px-6 py-3 text-left">Penyewa</th>
                        <th class="px-6 py-3 text-left">Barang</th>
                        <th class="px-6 py-3 text-center">Qty</th>
                        <th class="px-6 py-3 text-right">Denda</th>
                        <th class="px-6 py-3 text-left">Tanggal</th>
                    </tr>
                </thead>

                <tbody class="divide-y">

                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 transition">

                        
                        <td class="px-6 py-4">
                            <?php echo e(($data->currentPage() - 1) * $data->perPage() + $loop->iteration); ?>

                        </td>

                        
                        <td class="px-6 py-4 font-medium text-gray-700">
                            <?php echo e($item->transaksi->user->name); ?>

                        </td>

                        
                        <td class="px-6 py-4">
                            <?php echo e($item->barang->nama_barang); ?>

                        </td>

                        
                        <td class="px-6 py-4 text-center">
                            <?php echo e($item->qty); ?>

                        </td>

                        
                        <td class="px-6 py-4 text-right font-semibold text-red-500">
                            Rp <?php echo e(number_format($item->denda,0,',','.')); ?>

                        </td>

                        
                        <td class="px-6 py-4 text-gray-500">
                            <?php echo e($item->created_at->format('d M Y')); ?>

                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-10 text-gray-400">
                            Tidak ada data barang hilang
                        </td>
                    </tr>
                    <?php endif; ?>

                </tbody>

            </table>
        </div>

    </div>

    
    <div class="mt-6">
        <?php echo e($data->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/petugas/transaksi/hilang.blade.php ENDPATH**/ ?>
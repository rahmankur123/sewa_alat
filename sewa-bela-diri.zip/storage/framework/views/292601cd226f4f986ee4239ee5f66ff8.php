<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Rental</title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="min-h-screen bg-gradient-to-br from-slate-100 via-slate-200 to-slate-300">

<div class="min-h-screen flex items-center justify-center p-6">

    <div class="w-full max-w-6xl bg-white rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-2">

        
        
        
        <div class="bg-white p-8 md:p-14 flex flex-col justify-center">

            
            <div class="mb-8">
                <h2 class="text-4xl font-extrabold text-slate-800">
                    Login
                </h2>

                <p class="text-slate-500 mt-2 text-sm">
                    Selamat datang kembali di sistem penyewaan alat bela diri.
                </p>
            </div>

            
            <?php if(session('error')): ?>
            <div class="mb-5 bg-red-100 border border-red-300 text-red-700 px-4 py-3 rounded-2xl text-sm">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>

            
            <form method="POST" action="<?php echo e(route('login.proses')); ?>" class="space-y-5">
                <?php echo csrf_field(); ?>

                
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">
                        Email
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        placeholder="Masukkan email"
                        required
                        class="w-full rounded-2xl border border-slate-300 bg-slate-50 px-5 py-3 text-sm focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition"
                    >
                </div>

                
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">
                        Password
                    </label>

                    <input
                        type="password"
                        name="password"
                        placeholder="Masukkan password"
                        required
                        class="w-full rounded-2xl border border-slate-300 bg-slate-50 px-5 py-3 text-sm focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition"
                    >
                </div>

                
                <button
                    type="submit"
                    class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-2xl font-bold transition duration-300 shadow-lg hover:shadow-xl"
                >
                    Login Sekarang
                </button>
            </form>

            
            <div class="mt-8 text-sm text-slate-400">
                © <?php echo e(date('Y')); ?> Sistem Rental Alat Bela Diri
            </div>

        </div>


        
        
        
        <div class="hidden lg:flex relative bg-gradient-to-br from-blue-700 via-indigo-700 to-slate-900 text-white p-14 flex-col justify-center overflow-hidden">

            
            <div class="absolute inset-0 opacity-10">
                <div class="absolute top-0 left-0 w-72 h-72 bg-white rounded-full blur-3xl"></div>
                <div class="absolute bottom-0 right-0 w-96 h-96 bg-cyan-300 rounded-full blur-3xl"></div>
            </div>

            <div class="relative z-10">

                
                <div class="mb-8">
                    <div class="w-24 h-24 bg-white/10 backdrop-blur rounded-3xl flex items-center justify-center border border-white/20 shadow-xl">
                        <img
                            src="<?php echo e(asset('/storage/logo.jpg')); ?>"
                            alt="Logo"
                            class="w-16 h-16 justify-content-center object-contain"
                        >
                    </div>
                </div>

                
                <h1 class="text-5xl font-extrabold leading-tight mb-5">
                    BLACK <br>
                    DRAGGER CAMP
                </h1>

                
                <p class="text-blue-100 leading-relaxed text-lg max-w-md">
                    Sistem penyewaan alat bela diri modern yang membantu
                    pengelolaan transaksi, data anggota, stok barang,
                    dan laporan penyewaan secara cepat, aman, dan efisien.
                </p>

                
                <div class="mt-10 space-y-4">

                    <div class="flex items-center gap-4">
                        <div class="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center text-xl">
                            📦
                        </div>

                        <div>
                            <h3 class="font-bold">
                                Manajemen Barang
                            </h3>

                            <p class="text-sm text-blue-100">
                                Kelola stok alat bela diri dengan mudah.
                            </p>
                        </div>
                    </div>

                    <div class="flex items-center gap-4">
                        <div class="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center text-xl">
                            🧾
                        </div>

                        <div>
                            <h3 class="font-bold">
                                Transaksi Cepat
                            </h3>

                            <p class="text-sm text-blue-100">
                                Proses penyewaan lebih praktis dan efisien.
                            </p>
                        </div>
                    </div>

                    <div class="flex items-center gap-4">
                        <div class="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center text-xl">
                            📊
                        </div>

                        <div>
                            <h3 class="font-bold">
                                Laporan Otomatis
                            </h3>

                            <p class="text-sm text-blue-100">
                                Monitoring data penyewaan lebih akurat.
                            </p>
                        </div>
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

</body>
</html><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/auth/login.blade.php ENDPATH**/ ?>
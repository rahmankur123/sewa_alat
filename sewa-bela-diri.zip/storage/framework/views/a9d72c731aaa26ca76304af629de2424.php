

<?php $__env->startSection('content'); ?>

<div class="max-w-6xl mx-auto p-4 md:p-6">

    
    <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-3 mb-6">
        <div>
            <h2 class="text-xl md:text-2xl font-semibold text-gray-800">
                Detail Transaksi
            </h2>
            <p class="text-sm text-gray-500">
                Informasi lengkap transaksi penyewaan
            </p>
        </div>

        <a href="<?php echo e(url()->previous()); ?>"
           class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm w-fit">
            ← Kembali
        </a>
    </div>

    
    <div class="bg-white rounded-2xl shadow p-5 md:p-6 mb-6">

        <div class="grid grid-cols-2 md:grid-cols-3 gap-5 text-sm">

            <div>
                <p class="text-gray-400">No Transaksi</p>
                <p class="font-semibold text-gray-800">
                    #<?php echo e($transaksi->id); ?>

                </p>
            </div>

            <div>
                <p class="text-gray-400">Nama User</p>
                <p class="font-semibold text-gray-800">
                    <?php echo e($transaksi->user->name); ?>

                </p>
            </div>

            <div>
                <p class="text-gray-400">Status</p>
                <span class="inline-block px-3 py-1 text-xs rounded-full font-medium
                    <?php echo e($transaksi->status_transaksi == 'selesai' ? 'bg-green-100 text-green-600' : ''); ?>

                    <?php echo e($transaksi->status_transaksi == 'dipinjam' ? 'bg-yellow-100 text-yellow-600' : ''); ?>

                    <?php echo e($transaksi->status_transaksi == 'terlambat' ? 'bg-red-100 text-red-600' : ''); ?>">
                    <?php echo e(ucfirst($transaksi->status_transaksi)); ?>

                </span>
            </div>

            <div>
                <p class="text-gray-400">Tanggal Pinjam</p>
                <p>
                    <?php echo e(\Carbon\Carbon::parse($transaksi->tanggal_pinjam)->translatedFormat('d F Y')); ?>

                </p>
            </div>

            <div>
                <p class="text-gray-400">Rencana Kembali</p>
                <p>
                    <?php echo e(\Carbon\Carbon::parse($transaksi->tanggal_kembali_rencana)->translatedFormat('d F Y')); ?>

                </p>
            </div>

            <div>
                <p class="text-gray-400">Kembali Real</p>
                <p>
                    <?php echo e($transaksi->tanggal_kembali_real 
                        ? \Carbon\Carbon::parse($transaksi->tanggal_kembali_real)->translatedFormat('d F Y') 
                        : '-'); ?>

                </p>
            </div>

        </div>

        
        <div class="mt-6 flex flex-col md:flex-row md:justify-between md:items-center gap-4">

            <div class="bg-gray-50 px-4 py-3 rounded-xl">
                <p class="text-xs text-gray-500">Total Harga</p>
                <p class="text-lg font-semibold text-indigo-600">
                    Rp <?php echo e(number_format($transaksi->total_harga,0,',','.')); ?>

                </p>
            </div>

            <div class="bg-gray-50 px-4 py-3 rounded-xl">
                <p class="text-xs text-gray-500">Total Item</p>
                <p class="font-semibold text-gray-800">
                    <?php echo e($transaksi->detail->sum('qty')); ?> item
                </p>
            </div>

        </div>

    </div>


    
    <div class="bg-white rounded-2xl shadow overflow-hidden">

        <div class="px-5 py-4">
            <h3 class="font-semibold text-gray-800">
                Detail Barang
            </h3>
        </div>

        
        <div class="block md:hidden space-y-3 p-4">

            <?php $__currentLoopData = $transaksi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-50 p-3 rounded-xl text-sm">

                <p class="font-semibold text-gray-800">
                    <?php echo e($d->barang->nama_barang); ?>

                </p>

                <div class="flex justify-between text-xs mt-1 text-gray-500">
                    <span>Qty: <?php echo e($d->qty); ?></span>
                    <span>Rp <?php echo e(number_format($d->harga_per_hari,0,',','.')); ?></span>
                </div>

                <div class="text-right font-semibold text-indigo-600 mt-2">
                    Rp <?php echo e(number_format($d->subtotal,0,',','.')); ?>

                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


        
        <div class="hidden md:block overflow-x-auto">

            <table class="w-full text-sm">

                <thead class="text-gray-500 text-xs uppercase">
                    <tr>
                        <th class="px-6 py-3 text-left">Barang</th>
                        <th class="px-6 py-3 text-center">Qty</th>
                        <th class="px-6 py-3 text-right">Harga</th>
                        <th class="px-6 py-3 text-right">Subtotal</th>
                    </tr>
                </thead>

                <tbody class="divide-y">

                    <?php $total = 0; ?>

                    <?php $__currentLoopData = $transaksi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $total += $d->subtotal; ?>

                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <?php echo e($d->barang->nama_barang); ?>

                        </td>

                        <td class="px-6 py-4 text-center">
                            <?php echo e($d->qty); ?>

                        </td>

                        <td class="px-6 py-4 text-right text-gray-500">
                            Rp <?php echo e(number_format($d->harga_per_hari,0,',','.')); ?>

                        </td>

                        <td class="px-6 py-4 text-right font-semibold text-gray-800">
                            Rp <?php echo e(number_format($d->subtotal,0,',','.')); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

                <tfoot>
                    <tr class="bg-gray-50 font-semibold">
                        <td colspan="3" class="px-6 py-3 text-right">
                            Total
                        </td>
                        <td class="px-6 py-3 text-right text-indigo-600">
                            Rp <?php echo e(number_format($total,0,',','.')); ?>

                        </td>
                    </tr>
                </tfoot>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/petugas/transaksi/detail.blade.php ENDPATH**/ ?>
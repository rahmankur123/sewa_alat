
<?php $__env->startSection('title','Transaksi Terdenda'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto">

    
    <div class="mb-8">

        <h2 class="text-3xl font-bold tracking-tight text-slate-800">
            Transaksi Terdenda
        </h2>

        <p class="text-sm text-slate-500 mt-1">
            Daftar transaksi dengan total denda pembayaran
        </p>

    </div>

    
    <div class="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">

        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                
                <thead class="bg-slate-50 text-slate-500 uppercase text-xs tracking-wider">

                    <tr>
                        <th class="px-6 py-4 text-left font-semibold w-16">No</th>
                        <th class="px-6 py-4 text-left font-semibold">Nama User</th>
                        <th class="px-6 py-4 text-left font-semibold">Tanggal Sewa</th>
                        <th class="px-6 py-4 text-left font-semibold">Tanggal Kembali</th>
                        <th class="px-6 py-4 text-right font-semibold">Denda Keterlambatan</th>
                        <th class="px-6 py-4 text-right font-semibold">Denda Kerusakan</th>
                        <th class="px-6 py-4 text-right font-semibold">Denda Barang Hilang</th>
                        <th class="px-6 py-4 text-right font-semibold">Total Denda</th>
                        <th class="px-6 py-4 text-center font-semibold">Aksi</th>
                    </tr>

                </thead>

                
                <tbody class="divide-y divide-slate-100">

                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <?php
                    $denda_keterlambatan = $d->keterlambatan?->sum('total_denda') ?? 0;
                    $denda_kerusakan = $d->kerusakan?->sum('total_denda') ?? 0;
                    $denda_hilang = $d->hilang?->sum('denda') ?? 0;

                    $total_denda = $denda_keterlambatan + $denda_kerusakan + $denda_hilang;
                ?>

                <tr class="hover:bg-slate-50/70 transition duration-200">

                    
                    <td class="px-6 py-5 text-slate-500 font-medium">
                        <?php echo e(($data->currentPage() - 1) * $data->perPage() + $loop->iteration); ?>

                    </td>

                    
                    <td class="px-6 py-5">

                        <div class="flex items-center gap-3">

                            <div class="h-11 w-11 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-600 font-semibold">
                                <?php echo e(strtoupper(substr($d->user->name ?? '-',0,1))); ?>

                            </div>

                            <div class="font-semibold text-slate-700">
                                <?php echo e($d->user->name ?? '-'); ?>

                            </div>

                        </div>

                    </td>

                    
                    <td class="px-6 py-5 text-slate-600">
                        <?php echo e(\Carbon\Carbon::parse($d->tanggal_pinjam)->translatedFormat('d F Y')); ?>

                    </td>

                    
                    <td class="px-6 py-5 text-slate-600">

                        <?php echo e($d->tanggal_kembali_real
                            ? \Carbon\Carbon::parse($d->tanggal_kembali_real)->translatedFormat('d F Y')
                            : '-'); ?>


                    </td>

                    
                    <td class="px-6 py-5 text-right">

                        <?php if($denda_keterlambatan > 0): ?>

                            <span class="inline-block rounded-xl bg-orange-50 px-4 py-2 text-sm font-semibold text-orange-600">
                                Rp <?php echo e(number_format($denda_keterlambatan, 0, ',', '.')); ?>

                            </span>

                        <?php else: ?>
                            <span class="text-slate-400">-</span>
                        <?php endif; ?>

                    </td>

                    
                    <td class="px-6 py-5 text-right">

                        <?php if($denda_kerusakan > 0): ?>

                            <span class="inline-block rounded-xl bg-red-50 px-4 py-2 text-sm font-semibold text-red-600">
                                Rp <?php echo e(number_format($denda_kerusakan, 0, ',', '.')); ?>

                            </span>

                        <?php else: ?>
                            <span class="text-slate-400">-</span>
                        <?php endif; ?>

                    </td>

                    
                    <td class="px-6 py-5 text-right">

                        <?php if($denda_hilang > 0): ?>

                            <span class="inline-block rounded-xl bg-rose-50 px-4 py-2 text-sm font-semibold text-rose-600">
                                Rp <?php echo e(number_format($denda_hilang, 0, ',', '.')); ?>

                            </span>

                        <?php else: ?>
                            <span class="text-slate-400">-</span>
                        <?php endif; ?>

                    </td>

                    
                    <td class="px-6 py-5 text-right">

                        <span class="inline-block rounded-xl bg-red-100 px-4 py-2 text-sm font-bold text-red-700">
                            Rp <?php echo e(number_format($total_denda, 0, ',', '.')); ?>

                        </span>

                    </td>

                    
                    <td class="px-6 py-5 text-center">

                        <a href="<?php echo e(route('anggota.riwayat.detaildenda', $d->id)); ?>"
                           class="inline-block rounded-xl bg-blue-500 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-600 shadow-sm transition">
                            Detail Denda
                        </a>

                    </td>

                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="9" class="py-16 text-center">

                        <div class="flex flex-col items-center justify-center text-slate-400">

                            <div class="mb-3 text-5xl">
                                📦
                            </div>

                            <p class="text-sm font-medium">
                                Tidak ada transaksi terdenda
                            </p>

                        </div>

                    </td>

                </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

    
    <div class="mt-6">
        <?php echo e($data->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/anggota/riwayat/terdenda.blade.php ENDPATH**/ ?>
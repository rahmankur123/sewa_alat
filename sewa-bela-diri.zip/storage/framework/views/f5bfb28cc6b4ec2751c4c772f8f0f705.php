

<?php $__env->startSection('title','Detail Anggota'); ?>

<?php $__env->startSection('content'); ?>

<div 
    x-data="{ editMode: false }"
    class="max-w-6xl mx-auto px-4 py-6"
>

    
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">

        <div>
            <h1 class="text-3xl font-black text-slate-800 tracking-tight">
                Detail Anggota
            </h1>

            <p class="text-sm text-slate-500 mt-1">
                Informasi lengkap data anggota
            </p>
        </div>

        <div class="flex items-center gap-3">

            
            <button
                @click="editMode = !editMode"
                type="button"
                class="px-5 py-2.5 rounded-xl font-bold text-sm shadow-sm transition
                       bg-amber-500 hover:bg-amber-600 text-white"
            >
                <span x-text="editMode ? 'Batal Edit' : 'Edit Data'"></span>
            </button>

            
            <a href="<?php echo e(route('user.index')); ?>"
               class="px-5 py-2.5 rounded-xl font-bold text-sm shadow-sm transition
                      bg-slate-700 hover:bg-slate-800 text-white">
                ← Kembali
            </a>

        </div>

    </div>


    
    <?php if($errors->any()): ?>
        <div class="mb-6 rounded-2xl border border-red-200 bg-red-50 p-5">
            <div class="font-bold text-red-700 mb-2">
                Terjadi Kesalahan
            </div>

            <ul class="list-disc pl-5 text-sm text-red-600 space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <form
        action="<?php echo e(route('user.update',$user->id)); ?>"
        method="POST"
        enctype="multipart/form-data"
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

            
            
            
            <div class="bg-white rounded-3xl shadow-sm border border-slate-200 p-6 h-fit">

                <div class="flex flex-col items-center text-center">

                    
                    <?php if($user->foto): ?>
                        <img
                            src="<?php echo e(asset('storage/'.$user->foto)); ?>"
                            class="w-40 h-40 rounded-3xl object-cover border-4 border-slate-100 shadow"
                        >
                    <?php else: ?>
                        <div class="w-40 h-40 rounded-3xl bg-slate-100 flex items-center justify-center text-5xl">
                            👤
                        </div>
                    <?php endif; ?>

                    <h2 class="mt-4 text-xl font-black text-slate-800">
                        <?php echo e($user->name); ?>

                    </h2>

                    <p class="text-sm text-slate-500 capitalize">
                        <?php echo e($user->role); ?>

                    </p>

                </div>

                
                <div
                    x-show="editMode"
                    x-transition
                    class="mt-6"
                >
                    <label class="block text-sm font-bold text-slate-700 mb-2">
                        Ganti Foto Profil
                    </label>

                    <input
                        type="file"
                        name="foto"
                        class="w-full text-sm border border-slate-300 rounded-xl
                               file:border-0 file:bg-blue-600 file:text-white
                               file:px-4 file:py-2 file:mr-3 file:rounded-l-xl
                               hover:file:bg-blue-700"
                    >
                </div>

            </div>


            
            
            
            <div class="lg:col-span-2">

                <div class="bg-white rounded-3xl shadow-sm border border-slate-200 p-6">

                    <div class="flex items-center justify-between mb-6">

                        <div>
                            <h2 class="text-xl font-black text-slate-800">
                                Informasi Anggota
                            </h2>

                            <p class="text-sm text-slate-500">
                                Data pribadi anggota
                            </p>
                        </div>

                        <div
                            class="px-3 py-1 rounded-full text-xs font-bold
                                   bg-blue-100 text-blue-700"
                        >
                            ID #<?php echo e($user->id); ?>

                        </div>

                    </div>


                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">

                        
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Nama Lengkap
                            </label>

                            <template x-if="!editMode">
                                <div class="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-semibold text-slate-700">
                                    <?php echo e($user->name); ?>

                                </div>
                            </template>

                            <input
                                x-show="editMode"
                                type="text"
                                name="name"
                                value="<?php echo e(old('name',$user->name)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3
                                       focus:ring-4 focus:ring-blue-100 focus:border-blue-500
                                       outline-none"
                            >
                        </div>


                        
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Email
                            </label>

                            <template x-if="!editMode">
                                <div class="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-semibold text-slate-700">
                                    <?php echo e($user->email); ?>

                                </div>
                            </template>

                            <input
                                x-show="editMode"
                                type="email"
                                name="email"
                                value="<?php echo e(old('email',$user->email)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3
                                       focus:ring-4 focus:ring-blue-100 focus:border-blue-500
                                       outline-none"
                            >
                        </div>


                        
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Nomor HP
                            </label>

                            <template x-if="!editMode">
                                <div class="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-semibold text-slate-700">
                                    <?php echo e($user->no_hp ?? '-'); ?>

                                </div>
                            </template>

                            <input
                                x-show="editMode"
                                type="text"
                                name="no_hp"
                                value="<?php echo e(old('no_hp',$user->no_hp)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3
                                       focus:ring-4 focus:ring-blue-100 focus:border-blue-500
                                       outline-none"
                            >
                        </div>


                        
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Role
                            </label>

                            <div class="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-semibold capitalize text-slate-700">
                                <?php echo e($user->role); ?>

                            </div>
                        </div>


                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Alamat
                            </label>

                            <template x-if="!editMode">
                                <div class="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-semibold text-slate-700 min-h-[90px]">
                                    <?php echo e($user->alamat ?? '-'); ?>

                                </div>
                            </template>

                            <textarea
                                x-show="editMode"
                                name="alamat"
                                rows="4"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3
                                       focus:ring-4 focus:ring-blue-100 focus:border-blue-500
                                       outline-none"
                            ><?php echo e(old('alamat',$user->alamat)); ?></textarea>
                        </div>


                        
                        <div
                            x-show="editMode"
                            x-transition
                        >
                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Password Baru
                            </label>

                            <input
                                type="password"
                                name="password"
                                placeholder="Kosongkan jika tidak diubah"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3
                                       focus:ring-4 focus:ring-blue-100 focus:border-blue-500
                                       outline-none"
                            >
                        </div>


                        
                        <div
                            x-show="editMode"
                            x-transition
                        >
                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Konfirmasi Password
                            </label>

                            <input
                                type="password"
                                name="password_confirmation"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3
                                       focus:ring-4 focus:ring-blue-100 focus:border-blue-500
                                       outline-none"
                            >
                        </div>

                    </div>


                    
                    <div
                        x-show="editMode"
                        x-transition
                        class="mt-8 pt-6 border-t border-slate-200 flex justify-end"
                    >
                        <button
                            type="submit"
                            class="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700
                                   text-white font-bold shadow-sm transition"
                        >
                            Simpan Perubahan
                        </button>
                    </div>

                </div>

            </div>

        </div>

    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/petugas/user/edit.blade.php ENDPATH**/ ?>
<footer class="h-full flex items-center justify-center text-sm text-gray-500 bg-white">
    © <?php echo e(date('Y')); ?> Sistem Persewaan Alat Bela Diri — TA Rahman Kurniawan
</footer><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/partials/footer.blade.php ENDPATH**/ ?>
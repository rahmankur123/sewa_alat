
<?php $__env->startSection('title','Barang Hilang Saya'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-5xl mx-auto">

    
    <h2 class="text-2xl font-semibold text-slate-700 mb-6">
        Riwayat Barang Hilang
    </h2>

    
    <div class="bg-white shadow-sm rounded-xl border border-slate-200 overflow-hidden">

        <div class="overflow-x-auto">
            <table class="w-full text-sm">

                
                <thead class="bg-slate-100 text-slate-600 uppercase text-xs">
                    <tr>
                        <th class="px-6 py-3 text-left w-16">No</th>
                        <th class="px-6 py-3 text-left">Barang</th>
                        <th class="px-6 py-3 text-center w-24">Qty</th>
                        <th class="px-6 py-3 text-right w-40">Denda</th>
                        <th class="px-6 py-3 text-left w-40">Tanggal</th>
                    </tr>
                </thead>

                
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr class="border-t hover:bg-slate-50 transition">

                        
                        <td class="px-6 py-4">
                            <?php echo e(($data->currentPage() - 1) * $data->perPage() + $loop->iteration); ?>

                        </td>

                        
                        <td class="px-6 py-4 font-medium text-slate-700">
                            <?php echo e($item->barang->nama_barang); ?>

                        </td>

                        
                        <td class="px-6 py-4 text-center">
                            <?php echo e($item->qty); ?>

                        </td>

                        
                        <td class="px-6 py-4 text-right text-red-500 font-semibold">
                            Rp <?php echo e(number_format($item->denda,0,',','.')); ?>

                        </td>

                        
                        <td class="px-6 py-4">
                            <?php echo e(\Carbon\Carbon::parse($item->created_at)->translatedFormat('d F Y')); ?>

                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-10 text-slate-400">
                            Tidak ada riwayat barang hilang
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>

    </div>

    
    <div class="mt-4">
        <?php echo e($data->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/anggota/riwayat/hilang.blade.php ENDPATH**/ ?>
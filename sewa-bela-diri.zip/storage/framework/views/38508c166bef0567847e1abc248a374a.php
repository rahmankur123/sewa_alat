

<?php $__env->startSection('content'); ?>
<?php
    // Ambil prefix role dari URL, misalnya: petugas atau pemilik
    $prefix = request()->segment(1);
?>

<div class="p-6">

    <!-- Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <h1 class="text-2xl font-bold text-gray-800">
            Laporan Transaksi
        </h1>
    </div>

    <!-- Filter -->
    <form method="GET"
          action="<?php echo e(route($prefix . '.laporan.index')); ?>"
          class="bg-white rounded-xl shadow p-6 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-5 gap-4">

            <!-- Dari -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Dari Tanggal
                </label>
                <input type="date"
                       name="dari"
                       value="<?php echo e(request('dari')); ?>"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <!-- Sampai -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Sampai Tanggal
                </label>
                <input type="date"
                       name="sampai"
                       value="<?php echo e(request('sampai')); ?>"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <!-- Buttons -->
            <div class="md:col-span-3 flex items-end gap-2 flex-wrap">

                <!-- Filter -->
                <button type="submit"
                        class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow">
                    Filter
                </button>

                <!-- Reset -->
                <a href="<?php echo e(route($prefix . '.laporan.index')); ?>"
                   class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg shadow">
                    Reset
                </a>

                <!-- Export PDF -->
                <a href="<?php echo e(route($prefix . '.laporan.pdf', request()->all())); ?>"
                   target="_blank"
                   class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg shadow">
                    Export PDF
                </a>

                <!-- Barang Hilang -->
                <a href="<?php echo e(route($prefix . '.laporan.barang-hilang', request()->all())); ?>"
                   class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg shadow">
                    Barang Hilang
                </a>
            </div>
        </div>
    </form>

    <!-- Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">

        <!-- Total Sewa -->
        <div class="bg-white rounded-xl shadow p-6 border-l-4 border-blue-500">
            <p class="text-sm text-gray-500">Total Sewa</p>
            <h2 class="text-3xl font-bold text-blue-600 mt-2">
                Rp <?php echo e(number_format($total_sewa, 0, ',', '.')); ?>

            </h2>
        </div>

        <!-- Total Denda -->
        <div class="bg-white rounded-xl shadow p-6 border-l-4 border-yellow-500">
            <p class="text-sm text-gray-500">Total Denda</p>
            <h2 class="text-3xl font-bold text-yellow-600 mt-2">
                Rp <?php echo e(number_format($total_denda, 0, ',', '.')); ?>

            </h2>
        </div>

        <!-- Grand Total -->
        <div class="bg-white rounded-xl shadow p-6 border-l-4 border-green-500">
            <p class="text-sm text-gray-500">Grand Total</p>
            <h2 class="text-3xl font-bold text-green-600 mt-2">
                Rp <?php echo e(number_format($grand_total, 0, ',', '.')); ?>

            </h2>
        </div>
    </div>

    <!-- Table -->
    <div class="bg-white rounded-xl shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full">

                <!-- Table Head -->
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="px-4 py-3 text-left">No</th>
                        <th class="px-4 py-3 text-left">Kode Transaksi</th>
                        <th class="px-4 py-3 text-left">Penyewa</th>
                        <th class="px-4 py-3 text-left">Tanggal Pinjam</th>
                        <th class="px-4 py-3 text-right">Total Sewa</th>
                        <th class="px-4 py-3 text-right">Total Denda</th>
                        <th class="px-4 py-3 text-right">Grand Total</th>
                    </tr>
                </thead>

                <!-- Table Body -->
                <tbody class="divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $denda =
                                $item->kerusakan->sum('total_denda') +
                                $item->keterlambatan->sum('total_denda') +
                                $item->hilang->sum('denda');

                            $grand = $item->total_harga + $denda;
                        ?>

                        <tr class="hover:bg-gray-50">
                            <td class="px-4 py-3">
                                <?php echo e(($data->firstItem() ?? 1) + $loop->index); ?>

                            </td>

                            <td class="px-4 py-3 font-medium text-gray-700">
                                <?php echo e($item->kode_transaksi ?? $item->id); ?>

                            </td>

                            <td class="px-4 py-3">
                                <?php echo e($item->user->name ?? '-'); ?>

                            </td>

                            <td class="px-4 py-3">
                                <?php echo e(\Carbon\Carbon::parse($item->tanggal_pinjam)->format('d-m-Y')); ?>

                            </td>

                            <td class="px-4 py-3 text-right text-blue-600 font-semibold">
                                Rp <?php echo e(number_format($item->total_harga, 0, ',', '.')); ?>

                            </td>

                            <td class="px-4 py-3 text-right text-yellow-600 font-semibold">
                                Rp <?php echo e(number_format($denda, 0, ',', '.')); ?>

                            </td>

                            <td class="px-4 py-3 text-right text-green-600 font-bold">
                                Rp <?php echo e(number_format($grand, 0, ',', '.')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7"
                                class="px-4 py-6 text-center text-gray-500">
                                Tidak ada data transaksi.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

                <!-- Table Footer -->
                <tfoot class="bg-gray-100 font-bold">
                    <tr>
                        <td colspan="4"
                            class="px-4 py-3 text-right">
                            TOTAL
                        </td>

                        <td class="px-4 py-3 text-right text-blue-600">
                            Rp <?php echo e(number_format($total_sewa, 0, ',', '.')); ?>

                        </td>

                        <td class="px-4 py-3 text-right text-yellow-600">
                            Rp <?php echo e(number_format($total_denda, 0, ',', '.')); ?>

                        </td>

                        <td class="px-4 py-3 text-right text-green-600">
                            Rp <?php echo e(number_format($grand_total, 0, ',', '.')); ?>

                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if($data instanceof \Illuminate\Pagination\LengthAwarePaginator && $data->hasPages()): ?>
        <div class="mt-6">
            <?php echo e($data->withQueryString()->links()); ?>

        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/laporan/index.blade.php ENDPATH**/ ?>
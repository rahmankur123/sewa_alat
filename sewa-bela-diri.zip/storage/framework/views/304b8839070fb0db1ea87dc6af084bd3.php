<?php $__env->startSection('title','Laporan Penyewaan'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto p-6">

    
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">

        <div>
            <h1 class="text-2xl font-bold text-slate-800">
                Laporan Penyewaan
            </h1>

            <p class="text-sm text-slate-500 mt-1">
                Detail transaksi penyewaan dan denda
            </p>
        </div>

        
        <a href="<?php echo e(route(auth()->user()->role . '.laporan.penyewaan.pdf', request()->query())); ?>"
           class="inline-flex items-center gap-2 px-4 py-2.5 bg-red-500 hover:bg-red-600 text-white rounded-2xl shadow-sm transition text-sm font-medium">

            Export PDF

        </a>

    </div>

    
    <form method="GET"
          class="bg-white border border-slate-200 rounded-3xl shadow-sm p-5 mb-6">

        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">

            
            <div>
                <label class="block text-sm font-medium text-slate-600 mb-2">
                    Tanggal Awal
                </label>

                <input type="date"
                       name="tanggal_awal"
                       value="<?php echo e(request('tanggal_awal')); ?>"
                       class="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300 transition">
            </div>

            
            <div>
                <label class="block text-sm font-medium text-slate-600 mb-2">
                    Tanggal Akhir
                </label>

                <input type="date"
                       name="tanggal_akhir"
                       value="<?php echo e(request('tanggal_akhir')); ?>"
                       class="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300 transition">
            </div>

            
            <div>
                <label class="block text-sm font-medium text-slate-600 mb-2">
                    Status
                </label>

                <select name="status"
                        class="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300 transition">

                    <option value="">Semua Status</option>

                    <option value="dipinjam"
                        <?php echo e(request('status') == 'dipinjam' ? 'selected' : ''); ?>>
                        Dipinjam
                    </option>

                    <option value="selesai"
                        <?php echo e(request('status') == 'selesai' ? 'selected' : ''); ?>>
                        Selesai
                    </option>

                    <option value="terdenda"
                        <?php echo e(request('status') == 'terdenda' ? 'selected' : ''); ?>>
                        Terdenda
                    </option>

                </select>
            </div>

            
            <div class="flex items-end gap-2">

                <button type="submit"
                        class="flex-1 inline-flex items-center justify-center px-4 py-2.5 rounded-2xl bg-indigo-500 hover:bg-indigo-600 text-white text-sm font-medium shadow-sm transition">

                    Filter

                </button>

                <a href="<?php echo e(url(auth()->user()->role . '/laporan/penyewaan')); ?>"
                   class="inline-flex items-center justify-center px-4 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-medium transition">

                    Reset

                </a>

            </div>

        </div>

    </form>

    
    <div class="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden">

        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                
                <thead class="bg-slate-50 border-b border-slate-100">

                    <tr class="text-slate-500 uppercase text-xs tracking-wide">

                        <th class="px-6 py-4 text-left font-semibold">
                            Tanggal
                        </th>

                        <th class="px-6 py-4 text-left font-semibold">
                            Penyewa & Detail Barang
                        </th>

                        <th class="px-6 py-4 text-center font-semibold">
                            Status
                        </th>

                        <th class="px-6 py-4 text-right font-semibold">
                            Pembayaran
                        </th>

                    </tr>

                </thead>

                
                <tbody class="divide-y divide-slate-100">

<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<?php
    $dendaTerlambat =
        $t->keterlambatan?->sum('total_denda') ?? 0;

    $dendaRusak =
        $t->kerusakan?->sum('total_denda') ?? 0;

    $dendaHilang =
        $t->hilang?->sum('denda') ?? 0;

    $totalDenda =
        $dendaTerlambat +
        $dendaRusak +
        $dendaHilang;

    $totalBayar =
        $t->total_harga + $totalDenda;

    $totalQty =
        $t->detail?->sum('qty') ?? 0;
?>

<tr class="hover:bg-slate-50 transition">

    
    <td class="px-6 py-4 whitespace-nowrap text-slate-600">
        <?php echo e(\Carbon\Carbon::parse($t->tanggal_kembali_real ?? $t->created_at)->translatedFormat('d F Y')); ?>

    </td>

    
    <td class="px-6 py-4">

        <div class="font-semibold text-slate-700 mb-2">
            <?php echo e($t->user->name ?? '-'); ?>

        </div>

        
        <div class="flex flex-wrap gap-2">

            <?php $__currentLoopData = $t->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <span class="px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs">

                <?php echo e($detail->barang->nama_barang ?? '-'); ?>

                (x<?php echo e($detail->qty); ?>)

            </span>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </td>

    
    <td class="px-6 py-4 text-center">

        <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold capitalize

            <?php echo e($t->status_transaksi == 'dipinjam'
                ? 'bg-blue-100 text-blue-600'
                : ''); ?>


            <?php echo e($t->status_transaksi == 'selesai'
                ? 'bg-emerald-100 text-emerald-600'
                : ''); ?>


            <?php echo e($t->status_transaksi == 'terdenda'
                ? 'bg-red-100 text-red-600'
                : ''); ?>

        ">

            <?php echo e(str_replace('_',' ',$t->status_transaksi)); ?>


        </span>

    </td>

    
    <td class="px-6 py-4">

        <div class="space-y-1 text-sm">

            <div class="flex justify-between gap-4">
                <span class="text-slate-500">
                    Qty Barang
                </span>

                <span class="font-medium text-slate-700">
                    <?php echo e($totalQty); ?>

                </span>
            </div>

            <div class="flex justify-between gap-4">
                <span class="text-slate-500">
                    Total Sewa
                </span>

                <span class="font-medium text-slate-700">
                    Rp <?php echo e(number_format($t->total_harga,0,',','.')); ?>

                </span>
            </div>

            <div class="flex justify-between gap-4">
                <span class="text-slate-500">
                    Total Denda
                </span>

                <span class="<?php echo e($totalDenda > 0 ? 'text-red-500 font-semibold' : 'text-slate-400'); ?>">
                    Rp <?php echo e(number_format($totalDenda,0,',','.')); ?>

                </span>
            </div>

            <div class="flex justify-between gap-4 border-t pt-2 mt-2">

                <span class="font-semibold text-slate-700">
                    Total Bayar
                </span>

                <span class="font-bold text-indigo-600">
                    Rp <?php echo e(number_format($totalBayar,0,',','.')); ?>

                </span>

            </div>

        </div>

    </td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<tr>
    <td colspan="4"
        class="text-center py-14 text-slate-400">

        Tidak ada data laporan

    </td>
</tr>

<?php endif; ?>

</tbody>

            </table>

        </div>

    </div>

    
    <div class="mt-6">
        <?php echo e($data->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/laporan/penyewaan.blade.php ENDPATH**/ ?>
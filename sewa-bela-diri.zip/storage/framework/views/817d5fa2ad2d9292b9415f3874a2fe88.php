
<?php $__env->startSection('title','Transaksi Dipinjam'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto">

    
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">

        <div>
            <h2 class="text-3xl font-bold tracking-tight text-slate-800">
                Transaksi Dipinjam
            </h2>

            <p class="text-sm text-slate-500 mt-1">
                Daftar transaksi yang sedang berlangsung
            </p>
        </div>

    </div>

    
    <?php if(session('success')): ?>
    <div class="mb-6 flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 shadow-sm">

        <div class="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100">
            ✅
        </div>

        <div class="text-sm font-medium text-emerald-700">
            <?php echo e(session('success')); ?>

        </div>

    </div>
    <?php endif; ?>

    
    <?php if(session('error')): ?>
    <div class="mb-6 flex items-center gap-3 rounded-2xl border border-red-200 bg-red-50 px-5 py-4 shadow-sm">

        <div class="flex h-10 w-10 items-center justify-center rounded-full bg-red-100">
            ⚠️
        </div>

        <div class="text-sm font-medium text-red-700">
            <?php echo e(session('error')); ?>

        </div>

    </div>
    <?php endif; ?>

    
    <div class="mb-6">

        <div class="rounded-3xl border border-slate-200 bg-white shadow-sm p-4">

            <form method="GET" class="flex flex-col md:flex-row gap-3">

                <div class="flex-1">

                    <input 
                        type="text" 
                        name="search" 
                        value="<?php echo e(request('search')); ?>"
                        placeholder="Cari nama user..."
                        class="w-full rounded-2xl border border-slate-200 bg-slate-50 px-5 py-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-slate-400 focus:bg-white focus:outline-none focus:ring-4 focus:ring-slate-100 transition">

                </div>

                <button 
                    class="rounded-2xl bg-slate-800 px-6 py-3 text-sm font-medium text-white shadow-sm hover:bg-slate-700 hover:shadow-md transition duration-200">
                    Cari
                </button>

            </form>

        </div>

    </div>

    
    <div class="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">

        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                
                <thead class="bg-slate-50 text-slate-500 uppercase text-xs tracking-wider">

                    <tr>
                        <th class="px-6 py-4 text-center font-semibold">No</th>
                        <th class="px-6 py-4 text-left font-semibold">Nama User</th>
                        <th class="px-6 py-4 text-left font-semibold">Tanggal Sewa</th>
                        <th class="px-6 py-4 text-left font-semibold">Rencana Kembali</th>
                        <th class="px-6 py-4 text-center font-semibold">Aksi</th>
                    </tr>

                </thead>

                
                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr class="hover:bg-slate-50/70 transition duration-200">

                        
                        <td class="px-6 py-5 text-center text-slate-500 font-medium">
                            <?php echo e(($data->currentPage() - 1) * $data->perPage() + $loop->iteration); ?>

                        </td>

                        
                        <td class="px-6 py-5">

                            <div class="flex items-center gap-3">

                                <div class="h-11 w-11 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-600 font-semibold">
                                    <?php echo e(strtoupper(substr($d->user->name,0,1))); ?>

                                </div>

                                <div>
                                    <div class="font-semibold text-slate-700">
                                        <?php echo e($d->user->name); ?>

                                    </div>
                                </div>

                            </div>

                        </td>

                        
                        <td class="px-6 py-5 text-slate-600">
                            <?php echo e(\Carbon\Carbon::parse($d->tanggal_pinjam)->translatedFormat('d F Y')); ?>

                        </td>

                        
                        <td class="px-6 py-5 text-slate-600">
                            <?php echo e(\Carbon\Carbon::parse($d->tanggal_kembali_rencana)->translatedFormat('d F Y')); ?>

                        </td>

                        
                        <td class="px-6 py-5">

                            <div class="flex flex-wrap justify-center gap-2">

                                
                                <a href="<?php echo e(route('petugas.transaksi.detail', $d->id)); ?>"
                                   class="rounded-xl bg-slate-100 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 transition">
                                   Detail
                                </a>

                                
                                <a href="<?php echo e(route('petugas.transaksi.formKembalikan',$d->id)); ?>"
                                   class="rounded-xl bg-emerald-500 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-600 shadow-sm transition">
                                   Dikembalikan
                                </a>

                                
                                <form action="<?php echo e(route('petugas.transaksi.hapus',$d->id)); ?>" method="POST"
                                      onsubmit="return confirm('Yakin mau hapus data ini?')">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button class="rounded-xl bg-rose-500 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-600 shadow-sm transition">
                                        Hapus
                                    </button>

                                </form>

                            </div>

                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td colspan="5" class="py-16 text-center">

                            <div class="flex flex-col items-center justify-center text-slate-400">

                                <div class="mb-3 text-5xl">
                                    📦
                                </div>

                                <p class="text-sm font-medium">
                                    Data tidak ada
                                </p>

                            </div>

                        </td>
                    </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

    
    <div class="mt-6">
        <?php echo e($data->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/petugas/transaksi/dipinjam.blade.php ENDPATH**/ ?>
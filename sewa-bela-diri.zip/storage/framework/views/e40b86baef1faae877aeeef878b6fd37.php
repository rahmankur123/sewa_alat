

<?php $__env->startSection('title','Nota Denda'); ?>

<?php $__env->startSection('content'); ?>


<div class="no-print mb-4 flex justify-between max-w-4xl mx-auto">

    <a href="<?php echo e(url()->previous()); ?>"
       class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">
        ← Kembali
    </a>

    <button onclick="window.print()"
        class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
        🖨️ Cetak
    </button>

</div>


<div class="print-area max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-2xl shadow">

    
    <div class="flex justify-between items-start mb-8">

        <div>
            <h2 class="text-xl font-semibold text-gray-800">
                Nota Denda
            </h2>
            <p class="text-sm text-gray-500">
                Sistem Persewaan Alat Bela Diri
            </p>
        </div>

        <div class="text-right text-sm">
            <p class="text-gray-500">No Nota</p>
            <p class="font-semibold text-gray-800">
                INV-<?php echo e($transaksi->id); ?>-<?php echo e(date('Ymd')); ?>

            </p>
            <p class="text-gray-400">
                <?php echo e(now()->translatedFormat('d F Y')); ?>

            </p>
        </div>

    </div>

    
    <div class="grid grid-cols-2 gap-4 text-sm mb-8">

        <div>
            <p class="text-gray-400">Nama</p>
            <p class="font-medium"><?php echo e($transaksi->user->name); ?></p>
        </div>

        <div>
            <p class="text-gray-400">Status</p>
            <p class="capitalize font-medium">
                <?php echo e($transaksi->status_transaksi); ?>

            </p>
        </div>

        <div>
            <p class="text-gray-400">Tanggal Pinjam</p>
            <p>
                <?php echo e(\Carbon\Carbon::parse($transaksi->tanggal_pinjam)->translatedFormat('d F Y')); ?>

            </p>
        </div>

        <div>
            <p class="text-gray-400">Tanggal Kembali</p>
            <p>
                <?php echo e($transaksi->tanggal_kembali_real 
                    ? \Carbon\Carbon::parse($transaksi->tanggal_kembali_real)->translatedFormat('d F Y') 
                    : '-'); ?>

            </p>
        </div>

    </div>

    
    <?php
        $total_keterlambatan = $transaksi->keterlambatan->sum('total_denda');
        $total_kerusakan = $transaksi->kerusakan->sum('total_denda');
        $total_hilang = $transaksi->barangHilang->sum('denda');
        $total_denda = $total_keterlambatan + $total_kerusakan + $total_hilang;
    ?>

    
    <?php if($transaksi->keterlambatan->count()): ?>
    <div class="mb-6">
        <h3 class="text-sm font-semibold text-gray-700 mb-2">
            Denda Keterlambatan
        </h3>

        <div class="bg-gray-50 rounded-lg p-3 space-y-2 text-sm">
            <?php $__currentLoopData = $transaksi->keterlambatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex justify-between">
                <span><?php echo e($k->durasi_hari); ?> hari</span>
                <span class="text-red-500">
                    Rp <?php echo e(number_format($k->total_denda,0,',','.')); ?>

                </span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if($transaksi->kerusakan->count()): ?>
    <div class="mb-6">
        <h3 class="text-sm font-semibold text-gray-700 mb-2">
            Denda Kerusakan
        </h3>

        <div class="bg-gray-50 rounded-lg p-3 space-y-2 text-sm">
            <?php $__currentLoopData = $transaksi->kerusakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex justify-between">
                <span><?php echo e($k->barang->nama_barang); ?> (<?php echo e($k->qty); ?> <?php echo e($k->jenis_kerusakan); ?>)</span>
                <span class="text-red-500">
                    Rp <?php echo e(number_format($k->total_denda,0,',','.')); ?>

                </span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if($transaksi->barangHilang->count()): ?>
    <div class="mb-6">
        <h3 class="text-sm font-semibold text-gray-700 mb-2">
            Barang Hilang
        </h3>

        <div class="bg-gray-50 rounded-lg p-3 space-y-2 text-sm">
            <?php $__currentLoopData = $transaksi->barangHilang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex justify-between">
                <span><?php echo e($h->barang->nama_barang); ?> (<?php echo e($h->qty); ?>)</span>
                <span class="text-red-500">
                    Rp <?php echo e(number_format($h->denda,0,',','.')); ?>

                </span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="bg-gray-100 rounded-xl p-4 mt-6">

        <div class="flex justify-between text-sm mb-1">
            <span>Keterlambatan</span>
            <span class="text-red-500">Rp <?php echo e(number_format($total_keterlambatan,0,',','.')); ?></span>
        </div>

        <div class="flex justify-between text-sm mb-1">
            <span>Kerusakan</span>
            <span class="text-red-500">Rp <?php echo e(number_format($total_kerusakan,0,',','.')); ?></span>
        </div>

        <div class="flex justify-between text-sm mb-2">
            <span>Barang Hilang</span>
            <span class="text-red-500">Rp <?php echo e(number_format($total_hilang,0,',','.')); ?></span>
        </div>

        <div class="flex justify-between font-semibold text-lg border-t pt-2">
            <span>Total</span>
            <span class="text-red-600">
                Rp <?php echo e(number_format($total_denda,0,',','.')); ?>

            </span>
        </div>

    </div>

    
    <div class="mt-10 flex justify-between text-sm">

        <div class="text-gray-500">
            Harap segera melakukan pembayaran
        </div>

        <div class="text-right">
            <p>Petugas</p>
            <br><br>
            <p class="font-medium">
                <?php echo e(auth()->user()->name ?? 'Admin'); ?>

            </p>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/petugas/transaksi/detaildenda.blade.php ENDPATH**/ ?>
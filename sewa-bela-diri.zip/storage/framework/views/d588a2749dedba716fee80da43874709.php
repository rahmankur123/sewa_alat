
<?php $__env->startSection('title','Transaksi Baru'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto p-4 md:p-6">

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        
        
        
        <div class="lg:col-span-2">

            
            <div class="mb-5">
                <h2 class="text-2xl font-bold text-slate-800">
                    Transaksi Baru
                </h2>

                <p class="text-sm text-slate-500 mt-1">
                    Pilih barang yang akan disewa
                </p>
            </div>

            
            <div class="mb-5">
                <input
                    type="text"
                    id="searchBarang"
                    placeholder="Cari barang..."
                    class="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition"
                >
            </div>

            
            <div class="grid grid-cols-2 md:grid-cols-3 gap-5">

                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="barang-item bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-lg transition duration-300">

                    
                    <div class="h-40 overflow-hidden bg-slate-100">

                        <img
                            src="<?php echo e($b->foto ? asset('storage/'.$b->foto) : asset('img/default.png')); ?>"
                            class="w-full h-full object-cover hover:scale-105 transition duration-300"
                        >

                    </div>

                    
                    <div class="p-4">

                        <h3 class="nama-barang font-bold text-slate-800 line-clamp-1">
                            <?php echo e($b->nama_barang); ?>

                        </h3>

                        <div class="mt-3 flex items-center justify-between">

                            <div>
                                <p class="text-indigo-600 font-bold text-lg">
                                    Rp <?php echo e(number_format($b->harga_per_hari,0,',','.')); ?>

                                </p>

                                <p class="text-xs text-slate-400">
                                    per hari
                                </p>
                            </div>

                            <span class="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full">
                                Stok <?php echo e($b->stok); ?>

                            </span>

                        </div>

                        
                        <?php if($b->stok <= 0): ?>

                        <button
                            disabled
                            class="w-full mt-4 bg-slate-300 text-white py-2.5 rounded-2xl text-sm font-semibold cursor-not-allowed"
                        >
                            Stok Habis
                        </button>

                        <?php else: ?>

                        <button
                            type="button"
                            onclick="addToCart(
                                <?php echo e($b->id); ?>,
                                '<?php echo e($b->nama_barang); ?>',
                                <?php echo e($b->harga_per_hari); ?>

                            )"
                            class="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 rounded-2xl text-sm font-semibold transition"
                        >
                            + Tambah
                        </button>

                        <?php endif; ?>

                    </div>

                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>


        
        
        
        <div>

            <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 sticky top-4">

                
                <div class="mb-5">

                    <h2 class="text-2xl font-bold text-slate-800">
                        Keranjang
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Detail transaksi penyewaan
                    </p>

                </div>

                <form action="<?php echo e(route('petugas.transaksi.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    
                    <div class="mb-4">

                        <label class="block text-sm font-semibold text-slate-700 mb-2">
                            Pilih Anggota
                        </label>

                        <select
                            name="user_id"
                            required
                            class="w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-sm focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 outline-none transition"
                        >

                            <option value="">
                                -- Pilih Anggota --
                            </option>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($u->role == 'anggota'): ?>

                                <option value="<?php echo e($u->id); ?>">
                                    <?php echo e($u->name); ?>

                                </option>

                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </div>

                    
                    <div class="mb-4">

                        <label class="block text-sm font-semibold text-slate-700 mb-2">
                            Tanggal Pinjam
                        </label>

                        <input
                            type="date"
                            name="tanggal_pinjam"
                            id="tglPinjam"
                            value="<?php echo e(date('Y-m-d')); ?>"
                            required
                            class="w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-sm focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 outline-none transition"
                        >

                    </div>

                    
                    <div class="mb-4">

                        <label class="block text-sm font-semibold text-slate-700 mb-2">
                            Durasi Sewa
                        </label>

                        <select
                            id="durasi"
                            class="w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-sm focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 outline-none transition"
                        >

                            <?php for($i=1;$i<=9;$i++): ?>

                            <option value="<?php echo e($i); ?>">
                                <?php echo e($i); ?> Hari
                            </option>

                            <?php endfor; ?>

                        </select>

                        <input
                            type="hidden"
                            name="durasi"
                            id="durasiHidden"
                        >

                    </div>

                    
                    <div class="mb-5">

                        <label class="block text-sm font-semibold text-slate-700 mb-2">
                            Tanggal Kembali
                        </label>

                        <input
                            type="date"
                            name="tanggal_kembali_rencana"
                            id="tglKembali"
                            class="w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 py-3 text-sm"
                        >

                    </div>

                    
                    <div
                        id="cartList"
                        class="space-y-3 max-h-72 overflow-y-auto"
                    >

                        <div class="text-sm text-slate-400 text-center py-6">
                            Belum ada barang dipilih
                        </div>

                    </div>

                    
                    <div class="mt-5 border-t border-slate-200 pt-4">

                        <div class="flex items-center justify-between">

                            <span class="font-semibold text-slate-700">
                                Total
                            </span>

                            <span class="text-2xl font-bold text-indigo-600">
                                Rp <span id="totalHarga">0</span>
                            </span>

                        </div>

                    </div>

                    
                    <button
                        type="submit"
                        class="w-full mt-5 bg-green-600 hover:bg-green-700 text-white py-3 rounded-2xl font-bold transition"
                    >
                        Checkout
                    </button>

                </form>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>






<script>

let cart = [];
let total = 0;
let lamaSewa = 1;


// =========================
// SEARCH BARANG
// =========================
document.getElementById('searchBarang')
.addEventListener('keyup', function(){

    let keyword = this.value.toLowerCase();

    document.querySelectorAll('.barang-item')
    .forEach(item => {

        let nama = item.querySelector('.nama-barang')
            .innerText
            .toLowerCase();

        item.style.display =
            nama.includes(keyword)
            ? 'block'
            : 'none';

    });

});


// =========================
// ADD TO CART
// =========================
function addToCart(id, nama, harga){

    let item = cart.find(i => i.id === id);

    if(item){

        item.qty++;

    }else{

        cart.push({
            id,
            nama,
            harga,
            qty:1
        });

    }

    renderCart();

}


// =========================
// RENDER CART
// =========================
function renderCart(){

    let html = '';

    total = 0;

    lamaSewa = parseInt(
        document.getElementById('durasi').value
    );

    cart.forEach((item,i)=>{

        let sub =
            item.harga *
            item.qty *
            lamaSewa;

        total += sub;

        html += `
        <div class="border border-slate-200 rounded-2xl p-3">

            <div class="flex justify-between items-start gap-3">

                <div class="flex-1">

                    <p class="font-semibold text-sm text-slate-700">
                        ${item.nama}
                    </p>

                    <p class="text-xs text-slate-400 mt-1">
                        Rp ${item.harga.toLocaleString()} ×
                        ${item.qty} ×
                        ${lamaSewa} hari
                    </p>

                    <input type="hidden" name="barang_id[]" value="${item.id}">
                    <input type="hidden" name="qty[]" value="${item.qty}">

                </div>

                <div class="text-right">

                    <p class="font-bold text-indigo-600 text-sm">
                        Rp ${sub.toLocaleString()}
                    </p>

                    <div class="flex items-center justify-end gap-2 mt-2">

                        <button
                            type="button"
                            onclick="kurangItem(${i})"
                            class="w-7 h-7 rounded-lg bg-red-500 text-white"
                        >
                            -
                        </button>

                        <span class="text-sm font-semibold">
                            ${item.qty}
                        </span>

                        <button
                            type="button"
                            onclick="tambahItem(${i})"
                            class="w-7 h-7 rounded-lg bg-green-500 text-white"
                        >
                            +
                        </button>

                    </div>

                </div>

            </div>

        </div>
        `;

    });

    if(cart.length === 0){

        html = `
        <div class="text-sm text-slate-400 text-center py-6">
            Belum ada barang dipilih
        </div>
        `;

    }

    document.getElementById('cartList').innerHTML =
        html;

    document.getElementById('totalHarga').innerText =
        total.toLocaleString();

}


// =========================
// TAMBAH ITEM
// =========================
function tambahItem(i){

    cart[i].qty++;

    renderCart();

}


// =========================
// KURANG ITEM
// =========================
function kurangItem(i){

    cart[i].qty--;

    if(cart[i].qty <= 0){

        cart.splice(i,1);

    }

    renderCart();

}


// =========================
// DURASI CHANGE
// =========================
document.getElementById('durasi')
.addEventListener('change', function(){

    lamaSewa = parseInt(this.value);

    document.getElementById('durasiHidden').value =
        lamaSewa;

    updateTanggalKembali();

    renderCart();

});


// =========================
// TANGGAL PINJAM
// =========================
document.getElementById('tglPinjam')
.addEventListener('change', updateTanggalKembali);


// =========================
// UPDATE TANGGAL KEMBALI
// =========================
function updateTanggalKembali(){

    let tgl =
        document.getElementById('tglPinjam').value;

    if(!tgl) return;

    let parts = tgl.split('-');

    let tahun = parseInt(parts[0]);
    let bulan = parseInt(parts[1]) - 1;
    let hari = parseInt(parts[2]);

    let pinjam =
        new Date(tahun, bulan, hari);

    pinjam.setDate(
        pinjam.getDate() + lamaSewa
    );

    let yyyy = pinjam.getFullYear();

    let mm = String(
        pinjam.getMonth() + 1
    ).padStart(2,'0');

    let dd = String(
        pinjam.getDate()
    ).padStart(2,'0');

    document.getElementById('tglKembali').value =
        `${yyyy}-${mm}-${dd}`;

}


// =========================
// INIT
// =========================
window.onload = function(){

    lamaSewa = parseInt(
        document.getElementById('durasi').value
    );

    document.getElementById('durasiHidden').value =
        lamaSewa;

    updateTanggalKembali();

}

</script>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/petugas/transaksi/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title','Detail Transaksi'); ?>

<?php $__env->startSection('content'); ?>

<style>
/* ================= PRINT MODE ================= */
@media print {

    body * {
        visibility: hidden;
    }

    .print-area, .print-area * {
        visibility: visible;
    }

    .print-area {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
    }

    .no-print {
        display: none !important;
    }

    table {
        border-collapse: collapse;
        width: 100%;
    }

    table th, table td {
        border: 1px solid #000;
        padding: 6px;
    }
}
</style>

<h2 class="text-2xl font-semibold text-slate-700 mb-6 no-print">
    Detail Transaksi
</h2>


<div class="flex flex-wrap max-w-4xl mx-auto gap-3 mb-4 no-print">

    <a href="<?php echo e(route('petugas.transaksi.create')); ?>"
       class="px-4 py-2 bg-slate-500 text-white rounded-lg hover:bg-slate-600">
        + Transaksi Baru
    </a>

    <a href="<?php echo e(route('petugas.transaksi.dipinjam')); ?>"
       class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
        Data Dipinjam
    </a>

    <button onclick="window.print()"
       class="px-4 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition">
        🖨️ Cetak Nota
    </button>
</div>


<div class="print-area max-w-4xl mx-auto bg-white p-6 rounded-xl shadow-sm border border-slate-200">

    
    <div class="flex justify-between items-center border-b pb-4 mb-6">

        <div>
            <h2 class="text-xl font-bold text-slate-800">NOTA SEWA</h2>
            <p class="text-sm text-slate-500">Sistem Persewaan Alat Bela Diri</p>
        </div>

        <div class="text-right text-sm">
            <p>No Nota:</p>
            <p class="font-semibold">
                INV-SEWA-<?php echo e(date('Ymd')); ?>-<?php echo e($transaksi->id); ?>

            </p>
            <p class="text-slate-500">
                <?php echo e(now()->translatedFormat('d F Y')); ?>

            </p>
        </div>

    </div>

    
    <div class="grid grid-cols-2 gap-4 text-sm mb-6">

        <div>
            <p class="text-slate-500">Nama Penyewa</p>
            <p class="font-medium"><?php echo e($transaksi->user->name); ?></p>
        </div>

        <div>
            <p class="text-slate-500">Status</p>
            <p class="font-medium capitalize">
                <?php echo e($transaksi->status_transaksi); ?>

            </p>
        </div>

        <div>
            <p class="text-slate-500">Tanggal Pinjam</p>
            <p>
                <?php echo e(\Carbon\Carbon::parse($transaksi->tanggal_pinjam)->translatedFormat('d F Y')); ?>

            </p>
        </div>

        <div>
            <p class="text-slate-500">Rencana Kembali</p>
            <p>
                <?php echo e(\Carbon\Carbon::parse($transaksi->tanggal_kembali_rencana)->translatedFormat('d F Y')); ?>

            </p>
        </div>

    </div>

    
    <div class="overflow-x-auto mb-6">
        <table class="w-full text-sm border border-slate-200">

            <thead class="bg-slate-100 text-slate-600 text-xs uppercase">
                <tr>
                    <th class="p-2 text-left">Barang</th>
                    <th class="p-2 text-center">Qty</th>
                    <th class="p-2 text-right">Harga / Hari</th>
                    <th class="p-2 text-right">Subtotal</th>
                </tr>
            </thead>

            <tbody>

            <?php $total_sewa = 0; ?>

            <?php $__currentLoopData = $transaksi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $subtotal = $d->subtotal; // pakai dari DB
                    $total_sewa += $subtotal;
                ?>

                <tr class="border-t">
                    <td class="p-2"><?php echo e($d->barang->nama_barang); ?></td>
                    <td class="p-2 text-center"><?php echo e($d->qty); ?></td>
                    <td class="p-2 text-right">
                        Rp <?php echo e(number_format($d->harga_per_hari,0,',','.')); ?>

                    </td>
                    <td class="p-2 text-right font-medium">
                        Rp <?php echo e(number_format($subtotal,0,',','.')); ?>

                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr class="font-semibold bg-slate-50">
                <td colspan="3" class="p-2 text-right">Total Sewa</td>
                <td class="p-2 text-right">
                    Rp <?php echo e(number_format($total_sewa,0,',','.')); ?>

                </td>
            </tr>

            </tbody>
        </table>
    </div>

    
    <div class="bg-slate-50 border rounded-lg p-4 text-sm space-y-2">

        <div class="flex justify-between">
            <span>Total Sewa</span>
            <span class="font-semibold">
                Rp <?php echo e(number_format($total_sewa,0,',','.')); ?>

            </span>
        </div>

        <div class="flex justify-between font-bold text-lg border-t pt-2">
            <span>Total Bayar</span>
            <span>
                Rp <?php echo e(number_format($total_sewa,0,',','.')); ?>

            </span>
        </div>

    </div>

    
    <div class="mt-10 flex justify-between text-sm">

        <div>
            <p class="text-slate-500">Catatan:</p>
            <p class="text-slate-400">Terima kasih telah menggunakan layanan kami 🙏</p>
        </div>

        <div class="text-right">
            <p class="text-slate-600">Petugas</p>
            <br><br><br>
            <p class="border-t inline-block px-4 pt-1">
                <?php echo e(auth()->user()->name ?? 'Admin'); ?>

            </p>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/petugas/transaksi/show.blade.php ENDPATH**/ ?>
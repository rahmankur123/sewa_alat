<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Barang Hilang</title>

    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #000;
        }

        /* KOP SURAT */
        .kop-table {
            width: 100%;
            border: none;
            margin-bottom: 10px;
        }

        .kop-table td {
            border: none;
            vertical-align: top;
        }

        .logo {
            width: 80px;
        }

        .kop-text {
            text-align: center;
        }

        .kop-text h1 {
            margin: 0;
            font-size: 20px;
        }

        .kop-text h2 {
            margin: 2px 0;
            font-size: 16px;
        }

        .kop-text p {
            margin: 2px 0;
            font-size: 11px;
        }

        .line {
            border-top: 3px solid #000;
            margin-top: 8px;
            margin-bottom: 18px;
        }

        /* JUDUL */
        .judul {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 15px;
            text-transform: uppercase;
        }

        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000;
            padding: 6px;
            font-size: 11px;
        }

        th {
            background: #f2f2f2;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        /* FOOTER */
        .footer {
            margin-top: 40px;
            width: 100%;
        }

        .ttd {
            width: 250px;
            float: right;
            text-align: center;
        }

        .nama-ttd {
            margin-top: 60px;
            font-weight: bold;
            text-decoration: underline;
        }
    </style>
</head>

<body>

    
    <table class="kop-table">
        <tr>
            <td width="15%">
                <img src="<?php echo e(public_path('storage/logo.jpg')); ?>" class="logo">
            </td>

            <td class="kop-text">
                <h1>PERSEWAAN ALAT BELA DIRI</h1>
                <h2>CV. MAJU JAYA SPORT</h2>

                <p>
                    Jl. Contoh Alamat No. 123, Sukoharjo, Jawa Tengah
                </p>

                <p>
                    Telp: 0812-3456-7890 | Email: rental@example.com
                </p>
            </td>
        </tr>
    </table>

    <div class="line"></div>

    
    <div class="judul">
        Laporan Barang Hilang
    </div>

    
    <table>
        <thead>
            <tr>
                <th width="5%">No</th>
                <th>Tanggal</th>
                <th>Penyewa</th>
                <th>Barang</th>
                <th class="text-center">Qty</th>
                <th class="text-right">Denda</th>
            </tr>
        </thead>

        <tbody>
    <?php
        $no = 1;
        $grandTotal = 0;
    ?>

    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php $__currentLoopData = $t->hilang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $grandTotal += $h->denda;
            ?>

            <tr>
                <td class="text-center"><?php echo e($no++); ?></td>

                <td>
                    <?php echo e(\Carbon\Carbon::parse($t->tanggal_pinjam)->format('d/m/Y')); ?>

                </td>

                <td>
                    <?php echo e($t->user->name ?? '-'); ?>

                </td>

                <td>
                    <?php echo e($h->barang->nama_barang ?? '-'); ?>

                </td>

                <td class="text-center">
                    <?php echo e($h->qty); ?>

                </td>

                <td class="text-right">
                    Rp <?php echo e(number_format($h->denda, 0, ',', '.')); ?>

                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>
            <td colspan="6" class="text-center">
                Tidak ada data
            </td>
        </tr>

    <?php endif; ?>
</tbody>

<tfoot>
    <tr>
        <th colspan="5" class="text-right">
            TOTAL
        </th>

        <th class="text-right">
            Rp <?php echo e(number_format($grandTotal, 0, ',', '.')); ?>

        </th>
    </tr>
</tfoot>
    </table>

    
    <div class="footer">
        <div class="ttd">
            <p>
                Sukoharjo,
                <?php echo e(\Carbon\Carbon::now()->translatedFormat('d F Y')); ?>

            </p>

            <p>Petugas</p>

            <div class="nama-ttd">
                (................................)
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/laporan/pdf_barang_hilang.blade.php ENDPATH**/ ?>
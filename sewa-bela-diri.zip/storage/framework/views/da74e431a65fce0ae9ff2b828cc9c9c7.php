



<?php $__env->startSection('title', 'Laporan Transaksi'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto p-6">

    
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-semibold text-slate-700">
            Laporan Transaksi
        </h2>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">

        <div class="overflow-x-auto">
            <table class="w-full text-sm">

                <thead class="bg-slate-100 text-slate-600 uppercase text-xs">
                    <tr>
                        <th class="px-4 py-3 text-left">No</th>
                        <th class="px-4 py-3 text-left">Penyewa</th>
                        <th class="px-4 py-3 text-left">Barang</th>
                        <th class="px-4 py-3 text-center">Status</th>
                        <th class="px-4 py-3 text-right">Total Sewa</th>
                        <th class="px-4 py-3 text-right">Denda</th>
                        <th class="px-4 py-3 text-right">Total Bayar</th>
                        <th class="px-4 py-3 text-center">Tanggal</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <?php
                        $barang = $t->detail->map(function($d){
                            return $d->barang->nama_barang . ' (' . $d->qty . ')';
                        })->implode(', ');

                        $denda_keterlambatan = optional($t->keterlambatan)->sum('total_denda');
                        $denda_kerusakan = optional($t->kerusakan)->sum('total_denda');
                        $denda_hilang = optional($t->hilang)->sum('denda');

                        $total_denda =
                            $denda_keterlambatan +
                            $denda_kerusakan +
                            $denda_hilang;

                        $total_bayar = $t->total_harga + $total_denda;
                    ?>

                    <tr class="border-t hover:bg-slate-50">
                        <td class="px-4 py-3">
                            <?php echo e($data->firstItem() + $i); ?>

                        </td>

                        <td class="px-4 py-3">
                            <?php echo e($t->user->name ?? '-'); ?>

                        </td>

                        <td class="px-4 py-3">
                            <?php echo e($barang ?: '-'); ?>

                        </td>

                        <td class="px-4 py-3 text-center">
                            <span class="px-2 py-1 rounded-full text-xs capitalize
                                <?php echo e($t->status_transaksi == 'selesai' ? 'bg-green-100 text-green-600' : ''); ?>

                                <?php echo e($t->status_transaksi == 'terdenda' ? 'bg-red-100 text-red-600' : ''); ?>

                                <?php echo e($t->status_transaksi == 'dipinjam' ? 'bg-blue-100 text-blue-600' : ''); ?>

                                <?php echo e($t->status_transaksi == 'tersewa' ? 'bg-yellow-100 text-yellow-700' : ''); ?>">
                                <?php echo e(str_replace('_', ' ', $t->status_transaksi)); ?>

                            </span>
                        </td>

                        <td class="px-4 py-3 text-right">
                            Rp <?php echo e(number_format($t->total_harga, 0, ',', '.')); ?>

                        </td>

                        <td class="px-4 py-3 text-right text-red-500">
                            Rp <?php echo e(number_format($total_denda, 0, ',', '.')); ?>

                        </td>

                        <td class="px-4 py-3 text-right font-semibold">
                            Rp <?php echo e(number_format($total_bayar, 0, ',', '.')); ?>

                        </td>

                        <td class="px-4 py-3 text-center">
                            <?php echo e($t->created_at->format('d/m/Y')); ?>

                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-10 text-slate-400">
                            Belum ada data transaksi
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>

            </table>
        </div>

        
        <div class="p-4 border-t">
            <?php echo e($data->links()); ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/laporan/transaksi.blade.php ENDPATH**/ ?>
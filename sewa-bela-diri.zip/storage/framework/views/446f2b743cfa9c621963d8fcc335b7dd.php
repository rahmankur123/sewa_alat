

<?php $__env->startSection('title','Nota Sewa'); ?>

<?php $__env->startSection('content'); ?>

<div class="no-print mb-4 flex justify-between max-w-4xl mx-auto">

    <a href="<?php echo e(url()->previous()); ?>"
       class="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-800">
        ← Kembali
    </a>

    <button onclick="window.print()"
        class="px-4 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600">
        🖨️ Cetak Nota
    </button>

</div>

<div class="print-area max-w-4xl mx-auto bg-white p-6 rounded-xl shadow-sm border border-slate-200">

    
    <div class="flex justify-between items-center border-b pb-4 mb-6">
        <div>
            <h2 class="text-xl font-bold text-slate-800">NOTA SEWA</h2>
            <p class="text-sm text-slate-500">Sistem Persewaan Alat Bela Diri</p>
        </div>

        <div class="text-right text-sm">
            <p>No Nota:</p>
            <p class="font-semibold">
                INV-<?php echo e(date('Ymd')); ?>-<?php echo e($transaksi->id); ?>

            </p>
            <p class="mt-1 text-slate-500">
                <?php echo e(now()->translatedFormat('d F Y')); ?>

            </p>
        </div>
    </div>

    
    <div class="grid grid-cols-2 gap-6 text-sm mb-6">

        <div>
            <p class="text-slate-500">Nama Penyewa</p>
            <p class="font-medium"><?php echo e($transaksi->user->name); ?></p>
        </div>

        <div>
            <p class="text-slate-500">Status</p>
            <p class="font-medium capitalize">
                <?php echo e($transaksi->status_transaksi); ?>

            </p>
        </div>

        <div>
            <p class="text-slate-500">Tanggal Pinjam</p>
            <p>
                <?php echo e(\Carbon\Carbon::parse($transaksi->tanggal_pinjam)->translatedFormat('d F Y')); ?>

            </p>
        </div>

        <div>
            <p class="text-slate-500">Tanggal Kembali Rencana</p>
            <p>
                <?php echo e(\Carbon\Carbon::parse($transaksi->tanggal_kembali_rencana)->translatedFormat('d F Y')); ?>

            </p>
        </div>

        <div>
            <p class="text-slate-500">Tanggal Kembali</p>
            <p>
                <?php echo e($transaksi->tanggal_kembali_real 
                    ? \Carbon\Carbon::parse($transaksi->tanggal_kembali_real)->translatedFormat('d F Y') 
                    : '-'); ?>

            </p>
        </div>

    </div>

    
    <?php
        $total_sewa = $transaksi->detail->sum('subtotal');
        $denda_telat = $transaksi->keterlambatan->sum('total_denda');
        $denda_rusak = $transaksi->kerusakan->sum('total_denda');
        $denda_hilang = $transaksi->barangHilang->sum('denda');

        $total_denda = $denda_telat + $denda_rusak + $denda_hilang;
        $total_bayar = $total_sewa + $total_denda;
    ?>

    
    <h3 class="font-semibold text-slate-700 mb-2">Detail Barang</h3>

    <table class="w-full text-sm mb-6 border">
        <thead class="bg-slate-100 text-xs uppercase">
            <tr>
                <th class="p-2 border text-left">Barang</th>
                <th class="p-2 border text-center">Qty</th>
                <th class="p-2 border text-right">Harga/Hari</th>
                <th class="p-2 border text-right">Subtotal</th>
            </tr>
        </thead>

        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $transaksi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="p-2 border"><?php echo e($d->barang->nama_barang); ?></td>
                <td class="p-2 border text-center"><?php echo e($d->qty); ?></td>
                <td class="p-2 border text-right">
                    Rp <?php echo e(number_format($d->harga_per_hari,0,',','.')); ?>

                </td>
                <td class="p-2 border text-right">
                    Rp <?php echo e(number_format($d->subtotal,0,',','.')); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-center py-4 text-slate-400">
                    Tidak ada data barang
                </td>
            </tr>
        <?php endif; ?>

        <tr class="font-semibold bg-slate-50">
            <td colspan="3" class="p-2 border text-right">Total Sewa</td>
            <td class="p-2 border text-right">
                Rp <?php echo e(number_format($total_sewa,0,',','.')); ?>

            </td>
        </tr>

        </tbody>
    </table>

    
    <div class="grid grid-cols-3 gap-6 mb-6 text-sm">

        
        <div>
            <h4 class="font-semibold mb-2">Keterlambatan</h4>
            <?php $__empty_1 = true; $__currentLoopData = $transaksi->keterlambatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex justify-between border-b py-1">
                    <span><?php echo e($k->durasi_hari); ?> hari</span>
                    <span class="text-red-500">
                        Rp <?php echo e(number_format($k->total_denda,0,',','.')); ?>

                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-slate-400">Tidak ada</p>
            <?php endif; ?>
        </div>

        
        <div>
            <h4 class="font-semibold mb-2">Kerusakan</h4>
            <?php $__empty_1 = true; $__currentLoopData = $transaksi->kerusakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex justify-between border-b py-1">
                    <span><?php echo e($k->barang->nama_barang); ?> (<?php echo e($k->qty); ?>)</span>
                    <span class="text-red-500">
                        Rp <?php echo e(number_format($k->total_denda,0,',','.')); ?>

                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-slate-400">Tidak ada</p>
            <?php endif; ?>
        </div>

        
        <div>
            <h4 class="font-semibold mb-2">Barang Hilang</h4>
            <?php $__empty_1 = true; $__currentLoopData = $transaksi->barangHilang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex justify-between border-b py-1">
                    <span><?php echo e($h->barang->nama_barang); ?> (<?php echo e($h->qty); ?>)</span>
                    <span class="text-red-500">
                        Rp <?php echo e(number_format($h->denda,0,',','.')); ?>

                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-slate-400">Tidak ada</p>
            <?php endif; ?>
        </div>

    </div>

    
    <div class="bg-slate-50 border rounded-lg p-4 text-sm space-y-2">

        <div class="flex justify-between">
            <span>Total Sewa</span>
            <span>Rp <?php echo e(number_format($total_sewa,0,',','.')); ?></span>
        </div>

        <div class="flex justify-between">
            <span>Total Denda</span>
            <span class="text-red-500">
                Rp <?php echo e(number_format($total_denda,0,',','.')); ?>

            </span>
        </div>

        <div class="flex justify-between font-bold text-lg border-t pt-2">
            <span>Total Bayar</span>
            <span>
                Rp <?php echo e(number_format($total_bayar,0,',','.')); ?>

            </span>
        </div>

    </div>

    
    <div class="mt-10 flex justify-between text-sm">

        <div>
            <p class="text-slate-500">Catatan:</p>
            <p class="text-slate-400">Terima kasih telah menyewa 🙏</p>
        </div>

        <div class="text-right">
            <p class="text-slate-600">Petugas</p>
            <br><br><br>
            <p class="border-t inline-block px-4 pt-1">
                <?php echo e(auth()->user()->name ?? 'Admin'); ?>

            </p>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/anggota/riwayat/detailselesai.blade.php ENDPATH**/ ?>
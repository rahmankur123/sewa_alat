<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
<link href="https://cdn.jsdelivr.net/npm/tom-select/dist/css/tom-select.css" rel="stylesheet">
    <title><?php echo $__env->yieldContent('title'); ?> | Sewa Alat Bela Diri</title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <style>
        [x-cloak] {
            display: none !important;
        }

        @media print {
            body {
                background: white !important;
            }

            aside,
            header,
            footer,
            .no-print {
                display: none !important;
            }

            main {
                padding: 0 !important;
                margin: 0 !important;
            }
        }
    </style>
</head>

<body class="bg-slate-100 overflow-hidden">

<div x-data="{ open: false }" class="h-screen flex overflow-hidden">

    
    <aside
        :class="open ? 'translate-x-0' : '-translate-x-full'"
        class="fixed md:static inset-y-0 left-0 z-50
               w-72 bg-blue-600 text-white
               transition-all duration-300 transform
               md:translate-x-0 flex flex-col shadow-2xl"
    >
        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </aside>

    
    <div
        x-show="open"
        x-cloak
        @click="open = false"
        class="fixed inset-0 bg-black/50 z-40 md:hidden"
    ></div>

    
    <div class="flex-1 flex flex-col overflow-hidden">

        
        <header class="h-16 shrink-0 bg-white shadow-sm z-30">
            <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </header>

        
        <main class="flex-1 overflow-y-auto p-4 md:p-6">
            <div class="max-w-7xl mx-auto">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>

        
        <footer class="h-12 shrink-0 bg-white border-t">
            <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </footer>

    </div>

</div>

<script defer src="https://unpkg.com/alpinejs"></script>

<script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>

</body>
</html><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/layouts/app.blade.php ENDPATH**/ ?>
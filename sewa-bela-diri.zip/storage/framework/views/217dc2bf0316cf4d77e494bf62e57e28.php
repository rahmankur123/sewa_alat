

<?php $__env->startSection('title','Daftar Anggota'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto p-6">

    
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-semibold text-slate-700">
            Daftar Anggota
        </h1>

        <a href="<?php echo e(route('user.create')); ?>" 
           class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow-sm hover:bg-blue-700 transition text-sm">
            + Tambah Anggota
        </a>
    </div>

    
    <?php if(session('success')): ?>
    <div class="mb-4 p-4 rounded-lg bg-green-100 text-green-700 border border-green-300">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="mb-4 p-4 rounded-lg bg-red-100 text-red-700 border border-red-300">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    
    <form method="GET" 
        class="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6 flex flex-wrap gap-3 items-center">

        <input type="text" name="search" value="<?php echo e(request('search')); ?>"
            placeholder="Cari anggota..."
            class="border px-4 py-2 rounded-lg w-full md:w-1/4 text-sm focus:ring-2 focus:ring-slate-400 outline-none">

        <select name="status"
            class="border px-4 py-2 rounded-lg text-sm focus:ring-2 focus:ring-slate-400 outline-none">
            <option value="">Semua Status</option>
            <option value="aktif" <?php echo e(request('status')=='aktif'?'selected':''); ?>>Aktif</option>
            <option value="belum_aktif" <?php echo e(request('status')=='belum_aktif'?'selected':''); ?>>Belum Aktif</option>
        </select>

        <button class="px-4 py-2 bg-slate-800 text-white rounded-lg text-sm hover:bg-slate-700 transition">
            Filter
        </button>

    </form>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">

        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden 
                    hover:shadow-md hover:-translate-y-1 transition duration-300">

            
            <img src="<?php echo e($u->foto ? asset('storage/'.$u->foto) : asset('img/default.png')); ?>"
                 class="h-40 w-full object-cover">

            <div class="p-4 space-y-2">

                
                <h2 class="font-semibold text-lg text-slate-700">
                    <?php echo e($u->name); ?>

                </h2>

                
                <p class="text-xs text-slate-400">
                    <?php echo e($u->email); ?>

                </p>

                
                <p class="text-sm text-slate-500 line-clamp-2">
                    <?php echo e($u->alamat ?? '-'); ?>

                </p>

                
                <div class="flex gap-2 mt-3">

                    
                    <a href="<?php echo e(route('user.edit',$u->id)); ?>"
                       class="flex-1 text-center bg-yellow-500 text-white px-3 py-1 rounded text-xs hover:bg-yellow-600 transition">
                        Edit
                    </a>

                    
                    <form action="<?php echo e(route('user.destroy',$u->id)); ?>" method="POST" class="flex-1">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Hapus anggota ini?')"
                            class="w-full bg-red-600 text-white px-3 py-1 rounded text-xs hover:bg-red-700 transition">
                            Hapus
                        </button>
                    </form>

                </div>

            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-full text-center text-slate-400 py-10">
            Tidak ada data anggota
        </div>
        <?php endif; ?>

    </div>

    
    <div class="mt-6">
        <?php echo e($users->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/petugas/user/index.blade.php ENDPATH**/ ?>
<h2>Terima kasih telah melakukan transaksi</h2>

<p>Nama: <?php echo e($user->name); ?></p>
<p>Total: Rp <?php echo e(number_format($transaksi->total_harga)); ?></p>
<p>Status: <?php echo e($transaksi->status); ?></p>

<?php if($isBaru): ?>
<hr>
<h3>Akun Anda Belum Aktif</h3>
<p>Silakan aktivasi akun melalui link berikut:</p>

<a href="<?php echo e(url('aktivasi/'.$user->token_aktivasi)); ?>">
    Aktivasi Akun
</a>

<p>Token Aktivasi: <?php echo e($user->token_aktivasi); ?></p>
<?php endif; ?><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/emails/transaksi.blade.php ENDPATH**/ ?>
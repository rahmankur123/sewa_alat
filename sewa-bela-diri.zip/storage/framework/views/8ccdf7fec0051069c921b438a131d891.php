<header class="h-full bg-white px-4 md:px-6 flex items-center justify-between">

    
    <div class="flex items-center gap-4">

        
        <button
            @click="open = true"
            class="md:hidden w-10 h-10 rounded-lg hover:bg-slate-100 text-gray-700"
        >
            ☰
        </button>

        
        <div class="flex items-center gap-3">

            <img
                src="<?php echo e(asset('/storage/logo.jpg')); ?>"
                class="w-10 h-10 rounded-xl object-cover border"
            >

            <div class="hidden sm:block">
                <h1 class="font-bold text-gray-800 leading-tight">
                    Sistem Persewaan
                </h1>

                <p class="text-xs text-gray-500">
                    Alat Bela Diri
                </p>
            </div>

        </div>

    </div>

    
    <div class="flex items-center gap-4">

        
        <div class="hidden sm:block text-right">

            <h3 class="text-sm font-semibold text-gray-800">
                <?php echo e(auth()->user()->name); ?>

            </h3>

            <p class="text-xs text-gray-500 capitalize">
                <?php echo e(auth()->user()->role); ?>

            </p>

        </div>

        
        <img src="<?php echo e(asset('storage/' . auth()->user()->foto)); ?>"
             class="w-10 h-10 rounded-full object-cover border">

        
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <button
                class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition"
            >
                Logout
            </button>

        </form>

    </div>

</header><?php /**PATH D:\KULIAH MI\TA\sistem\sewa-bela-diri\resources\views/partials/header.blade.php ENDPATH**/ ?>